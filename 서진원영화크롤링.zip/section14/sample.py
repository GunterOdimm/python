#-----------------------------------------------------
# section14 - 웹 사이트 크롤링에서 사용할 URL 정보
#-----------------------------------------------------
# 웹 브라우저 버전 정보
user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"

# 네이버 뉴스 기사
naver_news_url = "https://news.naver.com/main/read.nhn?mode=LS2D&mid=shm&sid1=105&sid2=283&oid=008&aid=0004151505"

# 네이버 이미지 검색 결과 중 하나
image_url = 'http://blogfiles.naver.net/20111129_220/ktr38_1322533255591QJtWz_JPEG/s_1210_2011112414293493.jpg'


