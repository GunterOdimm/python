# -*- coding: utf-8 -*-
check_list = [True,False,False,True,False]
print(check_list)
for i in check_list:
	if i == True:
		i = False;
print(check_list)