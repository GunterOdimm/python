#-*-coding: utf-8 -*-

for i in range(0,5):
	star = ""

	for j in range(i,6-1):
		star = star + "*"
	
	print(star)