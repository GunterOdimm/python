#-*-coding: utf-8 -*-
def gugu(x):
	for i in range(1,10):
		ans = x * i
		tpl="{0}x{1}={2}"
		print(ans)
gugu(3)

gugu(5)